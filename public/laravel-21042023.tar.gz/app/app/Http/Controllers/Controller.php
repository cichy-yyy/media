<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\media;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected function GetMediaIdName()
    {
        $media = media::all();
        $i = 0;
        foreach($media as $row)
        {
            $data[$i]['id'] =  $row->id;
            $data[$i]['nazwa'] =  $row->nazwa;
            //$data[$row->id] =  $row->nazwa;
            $i++ ;
        }
        return $data??NULL;
    }
}
