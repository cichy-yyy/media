<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;
use App\Models\media;
use App\Http\Requests\AddMediaRequest;

class mediaController extends Controller
{
    public function add(): View
    {
        return view('media.add');
    }

    public function addData(AddMediaRequest $request)
    {
        $validated = $request->validated();
        $media = media::create([
            'nazwa' => $validated['nazwa'],
            'region' => $validated['region'],
            'miasto' => $validated['miasto'],
            'ulica' => $validated['ulica'],
            'kod' => $validated['kod_pocztowy'],
            'strona' => $validated['strona'],
            'telefon1' => $validated['telefon1'],
            'telefon2' => $validated['telefon2'],
            'telefon3' => $validated['telefon3'],
            'info' => $validated['informacje'],
            'email' => $validated['email'],
            'email2' => $validated['email2'],
            'email3' => $validated['email3'],
            'email4' => $validated['email4'],
            'opiekun' => $validated['opiekun']
        ]);

         return redirect()->route('media.edit')->with('message', 'Medium: '.$validated['nazwa'].' zostało dodane' );
    }

    public function Edit(int $idMedia = NULL)
    {
        $IdName = $this->GetMediaIdName();
        if ($IdName==NULL) {
            return redirect()->route('media.edit')->with('message', 'Brak agencji medialnych do edycji');
        }
        if (isset($idMedia)){
                $medium = media::OneMedia($idMedia)->get();
                if($medium->isEmpty()) return redirect()->route('media.edit')->with('message', 'Podana agencja medialna nie istnieje.');
                return view('media.edit', [
                    'name' => $IdName,
                    'details' => true,
                    'data' => $medium[0]
                ]);
        }else{
            return view('media.edit', ['name' => $IdName]);
        }
    }

    public function EditData(Request $request)
    {
        $IdName = $this->GetMediaIdName();
        $medium = media::OneMedia($request['MediumSelectedID'])->get();
        return view('media.edit', [
            'name' => $IdName,
            'details' => true,
            'data' => $medium[0]
        ]);
    }

    public function EditDataSave(AddMediaRequest $request)
    {

        $validated = $request->validated();
        $media = media::find($validated['id']);
        $media->nazwa = $validated['nazwa'];
        $media->region = $validated['region'];
        $media->opiekun = $validated['opiekun'];
        if($validated['miasto'])$media->miasto = $validated['miasto'];
        if($validated['ulica'])$media->ulica = $validated['ulica'];
        if($validated['kod_pocztowy'])$media->kod = $validated['kod_pocztowy'];
        if($validated['strona'])$media->strona = $validated['strona'];
        if($validated['telefon1'])$media->telefon1 = $validated['telefon1'];
        if($validated['telefon2'])$media->telefon2 = $validated['telefon2'];
        if($validated['telefon3'])$media->telefon3 = $validated['telefon3'];
        if($validated['informacje'])$media->info = $validated['informacje'];
        if($validated['email'])$media->email = $validated['email'];
        if($validated['email2'])$media->email2 = $validated['email2'];
        if($validated['email3'])$media->email3 = $validated['email3'];
        if($validated['email4'])$media->email4 = $validated['email4'];
        $media->save();

        return redirect()->route('media.edit')->with('message', 'Edycja medium: '.$validated['nazwa'].' zakończona powodzeniem.');
    }

    public function DeleteData(Request $request)
    {
        if($request->has('accept_delete_media'))
        {
            $media = media::find($request->input('id_delete'));
            $media->delete();
            return redirect()->route('media.edit')->with('message', 'Wpis został usunięty');
        }
        return view('delete',[
            'id_media' => $request->input('id'),
            'nazwa' => $request->input('nazwa')
        ]);
    }

    public function ShowMediaForm()
    {
        return view('media.showDetail', [
            'regions' => $this->showMediaData('region'),
            'opiekuni' => $this->showMediaData('opiekun')
        ]);
    }

    public function ShowMedia(Request $request)
    {
        if(isset($request->filtrRegion) && $request->filtrRegion != 'all'){
            if($request->filtrOpiekun != 'all'){
                $media = media::where(['region' => $request->filtrRegion, 'opiekun' => $request->filtrOpiekun])->get();
            }else{
                $media = media::where('region', $request->filtrRegion)->get();
            }
        }elseif(isset($request->filtrRegion) && $request->filtrRegion = 'all'){
                if($request->filtrOpiekun != 'all'){
                    $media = media::where('opiekun', $request->filtrOpiekun)->get();
                }else{
                    $media = media::all();
                }
        }
        return view('media.showDetail', [
            'regions'           => $this->showMediaData('region'),
            'opiekuni'          => $this->showMediaData('opiekun'),
            'details'           => true,
            'selectedRegion'     => $request->filtrRegion??FALSE,
            'selectedOpiekun'   => $request->filtrOpiekun??FALSE,
            'media'             => $media
        ]);
    }

    public function ShowMediaAjax(Request $request)
    {
        $media = media::find($request->idB);
        return view('media.ajaxMedia', [
            'mediaDetails' => $media
        ]);
    }

    public function showTable()
    {
        $media = media::select('id', 'nazwa', 'region', 'opiekun', 'miasto')->get();
        return view('media.showTable', [
            'media' => $media
        ]);

    }

    private function showMediaData($dataFind)
    {
        return  media::select($dataFind)->distinct()->orderBy($dataFind, 'asc')->get();
    }


}
