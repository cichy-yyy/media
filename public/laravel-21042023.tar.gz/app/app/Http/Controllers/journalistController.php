<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\journalist;
use App\Models\media;
use App\Http\Requests\AddJournalistRequest;

class journalistController extends Controller
{
    public function Add()
    {
        $media2 = media::select('id', 'nazwa')->get();
        return view('journalist.add',[
            'getMedia' => $media2
        ]);
    }

    public function AddData(AddJournalistRequest $request)
    {
        $validated = $request->validated();
        if(isset($validated['checklist'])? $medium = json_encode($validated['checklist']):  $medium = NULL);
        $journalist = journalist::create([
            'imie' => $validated['imie'],
            'nazwisko' => $validated['nazwisko'],
            'stanowisko' => $validated['stanowisko'],
            'region' => $validated['region'],
            'opiekun' => $validated['opiekun'],
            'telefon1' => $validated['telefon1'],
            'telefon2' => $validated['telefon2'],
            'email1' => $validated['email1'],
            'email2' => $validated['email2'],
            'email3' => $validated['email3'],
            'info' => $validated['informacje'],
            'medium' =>  $medium

        ]);
        return redirect()->route('journalist.add')->with('message', 'Dziennikarz: '.$validated['imie'].' '.$validated['nazwisko'].' został dodany' );
    }

    public function Edit()
    {

        $journalistList = journalist::select('id', 'imie', 'nazwisko')->get();
        return view('journalist.edit',[
            'journalist' => $journalistList,
            'details' => false
         ]);
    }

    public function EditData(Request $request, $id = NULL)
    {
        $id ??= $request['dziennikarz_edytowany'];
        $journalistList = journalist::select('id', 'imie', 'nazwisko')->get();
        // $journalistEdited = journalist::where('id', $request['dziennikarz_edytowany'])->get();
        $journalistEdited = journalist::where('id', $id)->get();
        $media = media::select('id', 'nazwa')->get();
        foreach($journalistEdited[0]->media as $role){
           $journalistMedia[] = $role->id;
        }
        $journalistMedia = $journalistMedia??[];
        //$journalistMedia = json_decode($journalistEdited[0]->medium)??[];
        //dump($journalistEdited);
        return view('journalist.edit',[
            'journalist' => $journalistList,
            'journalistEdited' => $journalistEdited[0],
            'details' => true,
            'getMedia' => $media,
            'journalistMedia' => $journalistMedia
         ]);
    }

    public function SaveData(AddJournalistRequest $request)
    {
        $validated = $request->validated();
        $journalistEdited = journalist::find($validated['id']);
        $journalistEdited->imie = $validated['imie'];
        $journalistEdited->nazwisko = $validated['nazwisko'];
        $journalistEdited->stanowisko = $validated['stanowisko'];
        $journalistEdited->region = $validated['region'];
        $journalistEdited->opiekun = $validated['opiekun'];
        $journalistEdited->telefon1 = $validated['telefon1'];
        $journalistEdited->telefon2 = $validated['telefon2'];
        $journalistEdited->email1 = $validated['email1'];
        $journalistEdited->email2 = $validated['email2'];
        $journalistEdited->email3    = $validated['email3'];
        $journalistEdited->info = $validated['informacje'];
        if(isset($validated['checklist']))
        {
            $journalistEdited->media()->sync($validated['checklist']    );
        }else
        {
            $journalistEdited->medium = NULL;
        };
        $journalistEdited->save();

        return redirect()->route('journalist.edit')->with('message', 'Dane dziennikarza: '.$validated['imie'].' '.$validated['nazwisko'].' zostały zaktualizowane.' );
    }

    public function show()
    {
        $journalistShow = journalist::select('id', 'imie', 'nazwisko', 'region', 'medium', 'opiekun')->get();
        $media = $this->GetMediaIdName();
        foreach ($journalistShow as $row)
        {
            $journalistData = NULL ;
        }

        //dump($journalistShow);
        // return view('journalist.show', [
        //     'journalist' => $journalistShow,
        //     'media' => $media
        // ]);
    }

    public function showTable()
    {
        $journalists = journalist::select('id', 'imie', 'nazwisko', 'region', 'opiekun')->get();
        return view('journalist.showTable', [
            'journalists' => $journalists
        ]);
    }
}


