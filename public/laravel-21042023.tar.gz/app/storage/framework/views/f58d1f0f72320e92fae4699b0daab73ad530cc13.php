<?php $__env->startSection('content'); ?>
<br/>
<div class="container">
    <div class="row justify-content-center pt-4">
        <div class="row">
            <div class="col-12">
                <div class="alert alert-success">
                    <?php echo e($message); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homeold', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/message.blade.php ENDPATH**/ ?>