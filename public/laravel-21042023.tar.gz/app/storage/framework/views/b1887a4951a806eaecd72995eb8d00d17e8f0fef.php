<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card">
        <div class="card-body" >
            <table class=" display" id="table_journalist" width="1200px" >
                <thead>
                    <tr>
                    <th scope="col">Imię</th>
                    <th scope="col">Nazwisko</th>
                    <th scope="col">Region działania</th>
                    <th scope="col">Opiekun</th>
                    <th scope="col">Medium</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $journalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journalistRow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($journalistRow->imie); ?></td>
                            <td><?php echo e($journalistRow->nazwisko); ?></td>
                            <td><?php echo e($journalistRow->region); ?></td>
                            <td><?php echo e($journalistRow->opiekun); ?></td>
                            <td><?php echo e($journalistRow->medium[1]); ?>

                                
                        </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    $(document).ready( function () {
        $('#table_journalist').DataTable({
                    "language": {
                        "lengthMenu": "Pokaż _MENU_ wpisów na stronę",
                        "zeroRecords": "Nic nie znalexiono - sorry",
                        "info": "Strona _PAGE_ z _PAGES_",
                        "infoEmpty": "Brak rekordów",
                        "infoFiltered": "(filtered from _MAX_ total records)",
						"sSearch": "Szukaj",
						"infoFiltered": " (_TOTAL_ spośród _MAX_ rekordów)",
						"paginate": {
						  "previous": "Wstecz",
						  "next": "Następna"
						}
                    }
                });
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/journalist/show.blade.php ENDPATH**/ ?>