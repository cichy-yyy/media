<?php $__env->startSection('content'); ?>
<style>
    .but {
        width: 200px;
        margin-bottom: 4px;
    }
</style>
<div class="container-fluid">
    <form action="<?php echo e(route('media.show')); ?>" method="post">
        <?php echo csrf_field(); ?>
    <p></p><H4><strong>Szybki podgląd wybranych agencji medialnych</strong></H4></p><br />
        <div class="row">
    <div class="col-4">
      <div class="card">
            <div class="card-body">
                <div class="form-group" id="filtr1">
                    <label for="filtr-1">Region:</label>
                    <select class="form-control" id="filtr-1"  name="filtrRegion">
                        <option value="all">Wszystkie</option>
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($region->region); ?> <?php if((isset($selectedRegion)) && $selectedRegion == $region->region): ?> selected="selected" <?php endif; ?>><?php echo e($region->region); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="col-4">
        <div class="card">
            <div class="card-body">
                <div class="form-group" id="filtr2">
                    <label for="filtr-2">Opiekun:</label>
                    <select class="form-control" id="filtr-2"  name="filtrOpiekun">';
                        <option value="all">Wszyscy</option>
                            <?php $__currentLoopData = $opiekuni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opiekun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($opiekun->opiekun); ?> <?php if((isset($selectedOpiekun)) && $selectedOpiekun == $opiekun->opiekun): ?> selected="selected" <?php endif; ?>><?php echo e($opiekun->opiekun); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>


  <input type="hidden" name="filtr_test"></div>
  <br /><button type="submit" class="btn btn-success">Pokaż</button></form><br />

  <?php if($details ?? false): ?>
  <div class="row col-12">
        <div class="col-6">
            <div class="card">
                <div class="card-body">
                <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneMedia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" data-id=<?php echo e($oneMedia->id); ?> class="btn btn-outline-primary but btn-sm ml-2" ><?php echo e($oneMedia->nazwa); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-6" id="data_media">
            Coś tam
        </div>
  <?php endif; ?>
  <script src="<?php echo e(asset('js/mediaAjax.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homeold', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/media/showDetail.blade.php ENDPATH**/ ?>