<?php $__env->startSection('content'); ?>

<div class="container mt-3">
    <div class="col-12">
        <div class="card"><div class="card-body">
            <table class=" display" id="table_id" width="1200px" >
                <thead>
                    <tr>
                    <th scope="col">Nazwa</th>
                    <th scope="col">Region działania</th>
                    <th scope="col">Opiekun</th>
                    <th scope="col">Miasto</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneMedia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href=<?php echo e(route('media.edit', ['idMedia' => $oneMedia->id])); ?>> <?php echo e($oneMedia->nazwa); ?> </a></td>
                            <td><?php echo e($oneMedia->region); ?></td>
                            <td><?php echo e($oneMedia->opiekun); ?></td>
                            <td><?php echo e($oneMedia->miasto); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </table>
        </div></div>
    </div>
</div>

        <script type="text/javascript">
        $(document).ready( function () {
            $('#table_id').DataTable({
                "language": {
                    "lengthMenu": "Pokaż _MENU_ wpisów na stronę",
                    "zeroRecords": "Nic nie znalexiono - sorry",
                    "info": "Strona _PAGE_ z _PAGES_",
                    "infoEmpty": "Brak rekordów",
                    "infoFiltered": "(filtered from _MAX_ total records)",
                    "sSearch": "Szukaj",
                    "infoFiltered": " (_TOTAL_ spośród _MAX_ rekordów)",
                    "paginate": {
                      "previous": "Wstecz",
                      "next": "Następna"
                    }
                }

            });
        } );
        </script>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('homeold', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/media/showTable.blade.php ENDPATH**/ ?>