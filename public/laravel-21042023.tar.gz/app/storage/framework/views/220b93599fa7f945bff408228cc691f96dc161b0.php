<?php $__env->startSection('content'); ?>

    <br /><br />
    <div class="container-lg">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('media.delete')); ?>">
                            <?php echo csrf_field(); ?>
                        <h2 style="color:#ff4d4d"><B>Czy jesteś pewien, że chcesz usunąć: <?php echo e($nazwa); ?>?</B></h2>
                        <input type="hidden" name="id_delete" value="<?php echo e($id_media); ?>">
                        <br /><button type="submit" class="btn btn-danger" name="accept_delete_media">Tak</button>&nbsp
                        <a  class="btn btn-success" href=<?php echo e(route('media.edit')); ?>>Nie</a>&nbsp
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('homeold', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/delete.blade.php ENDPATH**/ ?>