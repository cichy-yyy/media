<?php $__env->startSection('addJournalist'); ?>
Dodaj dziennikarza
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/journalist/journalist.blade.php ENDPATH**/ ?>