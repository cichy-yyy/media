<?php $__env->startSection('content'); ?>
     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <div class="container">
            <div class="row justify-content-center pt-4">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header"><b><?php echo e(__('Usuń użytkownika')); ?></b></div>

                        <div class="card-body">
                            <form action="" method="post">
                                <?php echo csrf_field(); ?>
                                <p> Wybierz użytkownika, którego chcesz usunąć:</p>
                                <select name="selectedUser" class="form-select form-select-sm mb-3">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($singleUser->id); ?>" <?php if(isset($user)): ?>  <?php if($singleUser->name == $user->name): ?> selected=selected <?php endif; ?> <?php endif; ?>><?php echo e($singleUser->name); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-danger btn-sm">Usuń</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php if($confirmDelete ?? FALSE): ?>
                    <div class="col-md-8 pt-4">
                        <div class="card">
                            <div class="card-body">
                                <form action="<?php echo e(route('deleteUserOk')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <p>Czy jesteś pewny, że chcesz na trwałe usunąć użytkownika: <b><?php echo e($user->name); ?></b> ?</p>
                                       <input type="hidden" name="deletingUser" value="<?php echo e($user->id); ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Potwierdzam</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <div class="container">
            <div class="row justify-content-center  pt-4">
                <div class="col-md-12">
                    <div class="alert alert-danger">
                        <div class="card-body">
                            Nie posiadasz uprawnień do usuwania użytkowników.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homeold', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/auth/deleteUser.blade.php ENDPATH**/ ?>