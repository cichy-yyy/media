<?php $__env->startSection('content'); ?>

<div class="container lg" style="margin-top: 10px">
    <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <?php if(session('message')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
<div class="row">
    <div class="col-12">
      <div class="card"><div class="card-body">
          <form action="<?php echo e(route('journalist.add.data')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <H4><strong>Wprowadź dane dziennikarza </strong></H4><br />
            <div class="input-group"><div class="input-group-prepend" ><span class="input-group-text" id="">Imię:</span></div> <input type="text" name="imie" class="form-control" required></div><br />
            <div class="input-group"><div class="input-group-prepend" ><span class="input-group-text" id="">Nazwisko:</span></div> <input type="text" name="nazwisko" class="form-control" required></div><br />
            <div class="input-group"><div class="input-group-prepend" ><span class="input-group-text" id="">Stanowisko:</span></div> <input type="text" name="stanowisko" class="form-control"></div><br />
            <div class="input-group"><div class="input-group-prepend"><span class="input-group-text"> Region działania: </span></div><input type="text" name="region" class="form-control" required></div><br />
            <div class="input-group"><div class="input-group-prepend"><span class="input-group-text"> Opiekun: </span></div><input type="text" name="opiekun" class="form-control"></div><br />
            <div class="input-group"><div class="input-group-prepend"><span class="input-group-text">  Telefon:</span></div><input type="text" name="telefon1" class="form-control"></div><br />
            <div class="input-group"><div class="input-group-prepend"><span class="input-group-text">  Telefon dodatkowy:</span></div><input type="text" name="telefon2" class="form-control"></div><br />
            <div class="input-group"><div class="input-group-prepend"><span class="input-group-text">  Adres e-mail:</span></div><input type="email" name="email1" placeholder="name@example.com" class="form-control"></div><br />
            <div class="input-group"><div class="input-group-prepend"><span class="input-group-text">  Dodatkowy adres e-mail:</span></div><input type="email" name="email2" placeholder="name@example.com" class="form-control"></div><br />
            <div class="input-group"><div class="input-group-prepend"><span class="input-group-text">  Dodatkowy adres e-mail:</span></div><input type="email" name="email3" placeholder="name@example.com" class="form-control"></div><br />
            <div class="input-group"><div class="input-group-prepend">  <B>Medium współpracujące:</B></div></div><br />
                <?php $__currentLoopData = $getMedia->chunk(40); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack40): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                    <?php $__currentLoopData = $pack40->chunk(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack10): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-3"><div class="card"><div class="card-body">
                            <?php $__currentLoopData = $pack10; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="checklist[]" value="<?php echo e($media->id); ?>" id="<?php echo e($media->id); ?>">
                                    <label class="form-check-label" for="<?php echo e($media->id); ?>"><?php echo e($media->nazwa); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div></div></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <br /><br />


                <div class="form-group">
                    <label for="Informacjie_o_uczestniku"><B>Podaj dodatkowe informacje</B></label>
                    <textarea class="form-control" id="Informacjie_o_uczestniku" name="informacje" rows="27"></textarea>
                </div>
                <input type="hidden" name="nowe_media">
                <br /><button type="submit" class="btn btn-success">Zapisz</button>

                </form>
            </div>
        </div>
    </div>
</div><br />
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('homeold', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/journalist/add.blade.php ENDPATH**/ ?>