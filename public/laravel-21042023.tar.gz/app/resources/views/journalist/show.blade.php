@extends('homeold')

@section('content')

<div class="col-12">
    <div class="card">
        <div class="card-body" >
            <table class=" display" id="table_journalist" width="1200px" >
                <thead>
                    <tr>
                    <th scope="col">Imię</th>
                    <th scope="col">Nazwisko</th>
                    <th scope="col">Region działania</th>
                    <th scope="col">Opiekun</th>
                    <th scope="col">Medium</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($journalist as $journalistRow )
                        <tr>
                            <td>{{$journalistRow->imie}}</td>
                            <td>{{$journalistRow->nazwisko}}</td>
                            <td>{{$journalistRow->region}}</td>
                            <td>{{$journalistRow->opiekun}}</td>
                            <td>{{$journalistRow->medium[1]}}
                                {{-- @foreach ($journalistRow->medium as $oneMedia )
                               {{ $media[$oneMedia] }}
                                @endforeach --}}
                        </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    $(document).ready( function () {
        $('#table_journalist').DataTable({
                    "language": {
                        "lengthMenu": "Pokaż _MENU_ wpisów na stronę",
                        "zeroRecords": "Nic nie znalexiono - sorry",
                        "info": "Strona _PAGE_ z _PAGES_",
                        "infoEmpty": "Brak rekordów",
                        "infoFiltered": "(filtered from _MAX_ total records)",
						"sSearch": "Szukaj",
						"infoFiltered": " (_TOTAL_ spośród _MAX_ rekordów)",
						"paginate": {
						  "previous": "Wstecz",
						  "next": "Następna"
						}
                    }
                });
    } );
</script>
@endsection
